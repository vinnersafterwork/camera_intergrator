package com.himanshu.cameraintegrator.exceptions

class CameraActivityNotFoundException(
    message: String
) : Exception(
    message
)