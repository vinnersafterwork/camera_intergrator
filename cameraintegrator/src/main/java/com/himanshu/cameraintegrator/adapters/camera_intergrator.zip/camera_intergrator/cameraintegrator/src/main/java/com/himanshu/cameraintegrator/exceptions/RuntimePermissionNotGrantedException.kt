package com.himanshu.cameraintegrator.exceptions

class RuntimePermissionNotGrantedException(
    message: String
) : Exception(
    message
)